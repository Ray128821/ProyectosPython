from copy import deepcopy


class Carta:
    def __init__(self, nombre, coste, ataque, vida, efecto=None, descripcion=""):
        self.nombre = nombre
        self.coste = coste
        self.ataque = ataque
        self.vida = vida
        self.vida_maxima = vida
        self.efecto = efecto
        self.descripcion = descripcion

    def esta_viva(self):
        return self.vida > 0

    def recibir_danio(self, cantidad):
        """Aplica el daño recibido y devuelve la cantidad aplicada."""
        danio = max(0, cantidad)
        self.vida = max(0, self.vida - danio)

        # El efecto de recibir daño se activa cuando el golpe causa daño.
        if danio > 0 and self.efecto:
            self.efecto(self, "recibir_danio")

        return danio

    def activar_efecto(self, evento):
        if self.efecto:
            self.efecto(self, evento)

    def __str__(self):
        return (
            f"{self.nombre} | coste {self.coste} | ATQ {self.ataque} "
            f"| VIDA {self.vida}/{self.vida_maxima}"
        )

    def copia(self):
        # Cada ejemplar jugado tiene sus propias estadísticas.
        return deepcopy(self)
