from cartas.carta import Carta
from efectos.efectos import efecto_guerrero, efecto_berserker


# 20 cartas disponibles para construir el mazo antes de cada partida.
CATALOGO = {
    "soldado": Carta("Soldado", 1, 1, 4, descripcion="Carta básica y económica."),
    "guerrero": Carta("Guerrero", 3, 3, 4, efecto=efecto_guerrero,
                      descripcion="Al morir, tu siguiente carta gana +3 ATQ."),
    "berserker": Carta("Berserker", 5, 1, 6, efecto=efecto_berserker,
                       descripcion="Cuando recibe daño, gana +1 ATQ."),
    "gigante": Carta("Gigante", 7, 5, 10, descripcion="Mucha vida y gran ataque."),
    "explorador": Carta("Explorador", 2, 2, 3, descripcion="Rápido y barato."),
    "guardia": Carta("Guardia", 2, 1, 7, descripcion="Resiste muchos golpes."),
    "cazador": Carta("Cazador", 3, 4, 3, descripcion="Mucho ataque para su coste."),
    "caballero": Carta("Caballero", 4, 3, 7, descripcion="Buenas estadísticas equilibradas."),
    "ogro": Carta("Ogro", 4, 4, 6, descripcion="Atacante resistente."),
    "lobo": Carta("Lobo", 2, 3, 3, descripcion="Ataca fuerte, pero tiene poca vida."),
    "arquera": Carta("Arquera", 3, 3, 4, descripcion="Atacante equilibrada."),
    "paladin": Carta("Paladín", 5, 3, 9, descripcion="Gran resistencia."),
    "troll": Carta("Trol", 5, 4, 8, descripcion="Difícil de derrotar."),
    "dragon": Carta("Dragón", 8, 7, 9, descripcion="Una carta muy poderosa."),
    "esqueleto": Carta("Esqueleto", 1, 2, 2, descripcion="Muy barato y frágil."),
    "golem": Carta("Gólem", 6, 3, 12, descripcion="Muchísima vida."),
    "asesino": Carta("Asesino", 4, 6, 2, descripcion="Ataque enorme y poca vida."),
    "minotauro": Carta("Minotauro", 6, 5, 8, descripcion="Fuerte en ataque y vida."),
    "curandero": Carta("Sanador", 3, 1, 6, descripcion="Resistente, aunque hace poco daño."),
    "coloso": Carta("Coloso", 9, 6, 14, descripcion="La carta más resistente del catálogo."),
}


def mostrar_catalogo():
    """Devuelve las 20 cartas en un orden estable para el menú."""
    return list(CATALOGO.items())


def crear_mazo_seleccionado(claves):
    """Crea copias independientes de las cartas elegidas."""
    return [CATALOGO[clave].copia() for clave in claves]


def crear_mazo_inicial():
    """Mazo predeterminado para usos externos al flujo normal del juego."""
    return crear_mazo_seleccionado(list(CATALOGO.keys())[:10])
