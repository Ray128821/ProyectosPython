class Jugador:
    def __init__(self, nombre):
        self.nombre = nombre
        self.vida = 20
        self.mana = 0
        self.mana_maximo = 10
        self.pool_cartas = []  # Las 5 cartas elegidas; se pueden robar infinitamente.
        self.mano = []
        self.linea = []  # Cartas propias en juego, de la más avanzada a la última.
        self.bono_siguiente_carta = 0

    def robar_aleatoria(self):
        """Añade a la mano una copia nueva de una carta elegida."""
        if self.pool_cartas:
            from random import choice
            self.mano.append(choice(self.pool_cartas).copia())
            return self.mano[-1]
        return None

    def recuperar_mana(self):
        self.mana = min(self.mana_maximo, self.mana + 4)

    def recibir_danio_jugador(self, cantidad):
        self.vida = max(0, self.vida - cantidad)
        print(f"{self.nombre} recibe {cantidad} de daño. Vida: {self.vida}")

    def mostrar_mano(self):
        print(f"\nMano de {self.nombre} (maná: {self.mana}):")
        if not self.mano:
            print("  (vacía)")
            return
        for indice, carta in enumerate(self.mano, start=1):
            print(f"  {indice}. {carta} — {carta.descripcion}")

    def mostrar_linea(self):
        if not self.linea:
            print("  (sin cartas en la línea)")
            return
        for indice, carta in enumerate(self.linea, start=1):
            posicion = "DELANTE" if indice == 1 else f"posición {indice}"
            print(f"  {posicion}: {carta}")
