import random

from cartas.catalogo import mostrar_catalogo, crear_mazo_seleccionado
from jugadores.jugador import Jugador


class Juego:
    def __init__(self):
        self.jugadores = [
            Jugador("Jugador 1"),
            Jugador("Jugador 2"),
        ]
        self.turno = 0
        self.opciones_seleccion = []

    def otro_jugador(self, jugador):
        return self.jugadores[1] if jugador is self.jugadores[0] else self.jugadores[0]

    def seleccionar_mazo(self, jugador):
        """Permite elegir 5 cartas distintas entre las 10 opciones de la partida."""
        print("\n" + "=" * 68)
        print(f"SELECCIÓN DE CARTAS — {jugador.nombre}")
        print("Elige 5 cartas distintas entre estas 10 opciones.")
        print("=" * 68)
        for numero, (_, carta) in enumerate(self.opciones_seleccion, start=1):
            print(
                f"{numero:2}. {carta.nombre:<13} "
                f"Coste {carta.coste:2} | ATQ {carta.ataque:2} | "
                f"VIDA {carta.vida:2} — {carta.descripcion}"
            )

        while True:
            respuesta = input(
                "\nEscribe los 5 números separados por comas (por ejemplo: 1,3,5,7,10):\n> "
            ).strip()
            try:
                numeros = [int(parte.strip()) for parte in respuesta.split(",")]
            except ValueError:
                print("Introduce únicamente números separados por comas.")
                continue

            if len(numeros) != 5:
                print(f"Tienes que elegir exactamente 5 cartas. Has indicado {len(numeros)}.")
                continue
            if len(set(numeros)) != 5:
                print("No puedes repetir una carta. Elige 5 números diferentes.")
                continue
            if any(numero < 1 or numero > len(self.opciones_seleccion) for numero in numeros):
                print("Los números válidos van del 1 al 10.")
                continue
            break

        claves = [self.opciones_seleccion[numero - 1][0] for numero in numeros]
        jugador.pool_cartas = crear_mazo_seleccionado(claves)
        print(f"\n{jugador.nombre} ha elegido:")
        for carta in jugador.pool_cartas:
            print(f"  - {carta.nombre}")

    def preparar_partida(self):
        # Los dos jugadores ven las mismas 10 opciones para que la selección sea justa.
        self.opciones_seleccion = random.sample(mostrar_catalogo(), 10)
        print("\nAntes de empezar, cada jugador elegirá 5 cartas entre las mismas 10 opciones.")
        for jugador in self.jugadores:
            input(f"\nPasa el dispositivo a {jugador.nombre} y pulsa Intro cuando esté listo...")
            self.seleccionar_mazo(jugador)

    def jugar_carta(self, jugador, indice_mano):
        carta = jugador.mano[indice_mano]

        if carta.coste > jugador.mana:
            print("No tienes suficiente maná.")
            return False

        jugador.mana -= carta.coste
        carta = jugador.mano.pop(indice_mano)

        if jugador.bono_siguiente_carta:
            carta.ataque += jugador.bono_siguiente_carta
            print(
                f"¡{carta.nombre} recibe +{jugador.bono_siguiente_carta} ATQ "
                "por el efecto del Guerrero!"
            )
            jugador.bono_siguiente_carta = 0

        # Las cartas se incorporan a la retaguardia. Nunca empujan
        # ni se enfrentan al ser jugadas.
        jugador.linea.append(carta)
        print(
            f"\n{jugador.nombre} juega {carta.nombre}. "
            f"Se coloca en la posición {len(jugador.linea)} de su línea."
        )
        return True

    def resolver_muerte(self, carta, propietario):
        carta.activar_efecto("morir")
        bono = getattr(carta, "bono_siguiente_carta", 0)
        if bono:
            propietario.bono_siguiente_carta += bono
            print(
                f"  Efecto: la siguiente carta de {propietario.nombre} "
                f"ganará +{bono} ATQ."
            )

    def avanzar_lineas(self):
        """Resuelve el combate de campo hasta que una de las líneas quede vacía.

        Si ambos tienen carta delantera, se enfrentan simultáneamente.
        Cuando una línea se queda sin cartas, cada carta restante de la otra
        línea golpea directamente al jugador rival con su ataque.
        """
        j1, j2 = self.jugadores

        while j1.linea and j2.linea:
            carta1 = j1.linea[0]
            carta2 = j2.linea[0]
            print(
                f"\\n¡ENFRENTAMIENTO! {carta1.nombre} "
                f"({j1.nombre}) vs {carta2.nombre} ({j2.nombre})"
            )

            ronda = 1
            while carta1.esta_viva() and carta2.esta_viva():
                print(f"  Ronda de combate {ronda}:")
                ataque1 = carta1.ataque
                ataque2 = carta2.ataque
                danio2 = carta2.recibir_danio(ataque1)
                danio1 = carta1.recibir_danio(ataque2)
                print(
                    f"    {carta1.nombre} causa {danio2} de daño. "
                    f"Vida de {carta2.nombre}: {carta2.vida}/{carta2.vida_maxima}"
                )
                print(
                    f"    {carta2.nombre} causa {danio1} de daño. "
                    f"Vida de {carta1.nombre}: {carta1.vida}/{carta1.vida_maxima}"
                )
                ronda += 1

            if not carta1.esta_viva():
                print(f"  {carta1.nombre} de {j1.nombre} ha sido derrotada.")
                self.resolver_muerte(carta1, j1)
                j1.linea.pop(0)

            if not carta2.esta_viva():
                print(f"  {carta2.nombre} de {j2.nombre} ha sido derrotada.")
                self.resolver_muerte(carta2, j2)
                j2.linea.pop(0)

        # Si una línea se vacía, el resto de cartas avanza y golpea al rival.
        if j1.linea and not j2.linea:
            self.ataque_directo(j1, j2)
        elif j2.linea and not j1.linea:
            self.ataque_directo(j2, j1)

    def ataque_directo(self, jugador, rival):
        """Todas las cartas que queden en la línea atacan al jugador rival."""
        while jugador.linea and rival.vida > 0:
            carta = jugador.linea.pop(0)
            danio = carta.ataque
            print(
                f"\\n{carta.nombre} de {jugador.nombre} avanza sin oposición "
                f"y causa {danio} de daño directo a {rival.nombre}."
            )
            rival.recibir_danio_jugador(danio)

    def mostrar_estado(self):
        print("\n" + "=" * 58)
        for jugador in self.jugadores:
            print(
                f"{jugador.nombre}: vida {jugador.vida} | "
                f"maná {jugador.mana} | cartas en su selección {len(jugador.pool_cartas)}"
            )
            print("Línea:")
            jugador.mostrar_linea()
        print("=" * 58)

    def turno_jugador(self, jugador):
        print(f"\n\n===== TURNO DE {jugador.nombre} =====")
        jugador.recuperar_mana()
        carta_recibida = jugador.robar_aleatoria()
        print(f"Recuperas maná. Ahora tienes {jugador.mana}.")
        if carta_recibida:
            print(f"Robas al azar: {carta_recibida.nombre} (de tus 5 cartas elegidas).")

        while True:
            self.mostrar_estado()
            jugador.mostrar_mano()
            print("\nOpciones:")
            print("  Número de carta: jugarla")
            print("  r: terminar de jugar cartas")
            print("  m: mostrar mano otra vez")

            opcion = input("> ").strip().lower()
            if opcion == "r":
                break
            if opcion == "m":
                continue
            if not opcion.isdigit():
                print("Opción no válida.")
                continue

            indice = int(opcion) - 1
            if indice < 0 or indice >= len(jugador.mano):
                print("Ese número no corresponde a una carta.")
                continue

            self.jugar_carta(jugador, indice)

        self.avanzar_lineas()

    def ejecutar(self):
        print("====================================")
        print("       JUEGO DE CARTAS - PRUEBA")
        print("====================================")
        print("Dos jugadores por turnos en la misma consola.")
        print("Cada jugador elige 5 cartas entre 10 opciones y recibe una al azar cada turno.")
        print("Pulsa Intro para pasar el dispositivo al siguiente jugador.")
        self.preparar_partida()

        while all(j.vida > 0 for j in self.jugadores):
            jugador = self.jugadores[self.turno]
            input(f"\nTurno de {jugador.nombre}. Pulsa Intro para continuar...")
            self.turno_jugador(jugador)

            if any(j.vida <= 0 for j in self.jugadores):
                break

            self.turno = 1 - self.turno

        ganador = next((j for j in self.jugadores if j.vida > 0), None)
        print("\n===== FIN DE LA PARTIDA =====")
        if ganador:
            print(f"¡{ganador.nombre} gana!")
        else:
            print("La partida termina en empate.")
