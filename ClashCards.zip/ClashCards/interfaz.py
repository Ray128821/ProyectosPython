import random
import tkinter as tk
from tkinter import messagebox
from contextlib import redirect_stdout
from io import StringIO

from combate.motor import Juego
from cartas.catalogo import mostrar_catalogo, crear_mazo_seleccionado


FONDO = "#101827"
PANEL = "#1d2a3d"
CARTA = "#263b55"
ACENTO = "#e0b45c"
TEXTO = "#f4f1e8"
SUAVE = "#b9c4d2"

# Cada familia tiene un color y un símbolo sencillo para identificarla.
SPRITES = {
    "soldado": ("#6e9acb", "S"), "guerrero": ("#c66b45", "G"),
    "berserker": ("#c94d4d", "B"), "gigante": ("#8d79b8", "Gi"),
    "explorador": ("#65a887", "E"), "guardia": ("#7d9aab", "Gu"),
    "cazador": ("#9caa62", "C"), "caballero": ("#c2a15d", "K"),
    "ogro": ("#6d9b65", "O"), "lobo": ("#8b9aaa", "L"),
    "arquera": ("#b77a9d", "A"), "paladin": ("#d0b85f", "P"),
    "troll": ("#6d9b82", "T"), "dragon": ("#c65d42", "D"),
    "esqueleto": ("#c5cbd2", "Es"), "golem": ("#8d8c85", "Go"),
    "asesino": ("#8a6e9e", "As"), "minotauro": ("#ae7655", "M"),
    "curandero": ("#62aaa5", "+"), "coloso": ("#9c805a", "Co"),
}


def clave_carta(carta):
    nombre = carta.nombre.lower()
    equivalencias = {"sanador": "curandero", "trol": "troll", "paladín": "paladin"}
    return equivalencias.get(nombre, nombre)


def dibujar_sprite(canvas, clave, grande=False):
    """Sprite vectorial sencillo, sin archivos externos."""
    color, simbolo = SPRITES.get(clave, ("#7890a8", "?"))
    canvas.delete("all")
    w = int(canvas["width"])
    h = int(canvas["height"])
    canvas.create_rectangle(2, 2, w-2, h-2, fill="#172337", outline=ACENTO, width=2)
    # Silueta: cabeza, cuerpo, brazos y base.
    cx = w // 2
    canvas.create_oval(cx-10, 8, cx+10, 28, fill=color, outline="#f4f1e8", width=1)
    canvas.create_polygon(cx-15, 31, cx+15, 31, cx+20, h-13,
                          cx-20, h-13, fill=color, outline="#f4f1e8")
    canvas.create_line(cx-13, 39, 7, h-25, fill=color, width=5)
    canvas.create_line(cx+13, 39, w-7, h-25, fill=color, width=5)
    canvas.create_text(cx, h-20, text=simbolo, fill="#ffffff",
                       font=("Arial", 9 if grande else 8, "bold"))


class InterfazJuego:
    def __init__(self, root):
        self.root = root
        self.root.title("Duelo de cartas")
        self.root.geometry("1180x820")
        self.root.minsize(920, 680)
        self.root.configure(bg=FONDO)
        self.juego = Juego()
        self.seleccion = set()
        self.jugador_seleccion = 0
        self.jugadores_eligieron = set()
        self.ronda_preparada = False
        self.log_combate = []
        self._construir_inicio()

    def limpiar(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def titulo(self, padre, texto, size=22):
        tk.Label(padre, text=texto, bg=FONDO, fg=ACENTO,
                 font=("Arial", size, "bold")).pack(pady=8)

    def _construir_inicio(self):
        self.limpiar()
        tk.Label(self.root, text="DUELO DE CARTAS", bg=FONDO, fg=ACENTO,
                 font=("Arial", 34, "bold")).pack(pady=(115, 18))
        tk.Label(self.root, text="Elige tu estrategia. Prepara tu línea. ¡Combate!",
                 bg=FONDO, fg=TEXTO, font=("Arial", 15)).pack(pady=8)
        tk.Button(self.root, text="EMPEZAR PARTIDA", command=self.iniciar_seleccion,
                  bg=ACENTO, fg="#172033", activebackground="#f0cb79",
                  font=("Arial", 16, "bold"), padx=28, pady=14, relief="flat").pack(pady=42)
        tk.Label(self.root, text="Dos jugadores · Selección de mazo · Rondas simultáneas",
                 bg=FONDO, fg=SUAVE, font=("Arial", 11)).pack()

    def iniciar_seleccion(self):
        self.juego.opciones_seleccion = random.sample(mostrar_catalogo(), 10)
        self.jugador_seleccion = 0
        self.mostrar_seleccion()

    def mostrar_seleccion(self):
        self.limpiar()
        jugador = self.juego.jugadores[self.jugador_seleccion]
        self.seleccion = set()
        self.titulo(self.root, f"ELIGE EL MAZO DE {jugador.nombre.upper()}")
        tk.Label(self.root, text="Selecciona 5 cartas. Cada carta tiene su propio sprite.",
                 bg=FONDO, fg=TEXTO, font=("Arial", 12)).pack()
        self.contador = tk.Label(self.root, text="0 / 5 seleccionadas",
                                 bg=FONDO, fg=ACENTO, font=("Arial", 12, "bold"))
        self.contador.pack(pady=6)
        grid = tk.Frame(self.root, bg=FONDO)
        grid.pack(expand=True, fill="both", padx=28, pady=8)
        self.botones_cartas = {}
        for i, (clave, carta) in enumerate(self.juego.opciones_seleccion):
            celda = tk.Frame(grid, bg=CARTA, padx=7, pady=6)
            celda.grid(row=i//2, column=i%2, sticky="nsew", padx=6, pady=5)
            sprite = tk.Canvas(celda, width=54, height=65, bg="#172337",
                               highlightthickness=0)
            sprite.pack(side="left", padx=(0, 9))
            dibujar_sprite(sprite, clave)
            texto = (f"{carta.nombre}\nCoste {carta.coste}  ·  ATQ {carta.ataque}  ·  VIDA {carta.vida}\n"
                     f"{carta.descripcion}")
            b = tk.Button(celda, text=texto, command=lambda k=clave: self.alternar(k),
                          wraplength=330, justify="left", anchor="w",
                          bg=CARTA, fg=TEXTO, activebackground=ACENTO,
                          font=("Arial", 10), relief="flat")
            b.pack(side="left", fill="both", expand=True)
            self.botones_cartas[clave] = (celda, b)
        for r in range(5):
            grid.rowconfigure(r, weight=1)
        for c in range(2):
            grid.columnconfigure(c, weight=1)
        self.boton_continuar = tk.Button(self.root, text="CONFIRMAR MAZO",
                  command=self.confirmar_mazo, state="disabled",
                  bg=ACENTO, fg="#172033", font=("Arial", 12, "bold"),
                  padx=18, pady=9, relief="flat")
        self.boton_continuar.pack(pady=10)

    def alternar(self, clave):
        if clave in self.seleccion:
            self.seleccion.remove(clave)
        elif len(self.seleccion) < 5:
            self.seleccion.add(clave)
        else:
            return
        self.contador.config(text=f"{len(self.seleccion)} / 5 seleccionadas")
        for k, (celda, boton) in self.botones_cartas.items():
            elegido = k in self.seleccion
            celda.config(bg="#705d32" if elegido else CARTA)
            boton.config(bg="#705d32" if elegido else CARTA,
                         fg=TEXTO)
        self.boton_continuar.config(state="normal" if len(self.seleccion) == 5 else "disabled")

    def confirmar_mazo(self):
        jugador = self.juego.jugadores[self.jugador_seleccion]
        claves = [k for k, _ in self.juego.opciones_seleccion if k in self.seleccion]
        jugador.pool_cartas = crear_mazo_seleccionado(claves)
        if self.jugador_seleccion == 0:
            self.jugador_seleccion = 1
            messagebox.showinfo("Cambio de jugador", "Pasa el dispositivo al Jugador 2 para que elija su mazo.")
            self.mostrar_seleccion()
        else:
            self.juego.turno = 0
            self.preparar_ronda()
            self.mostrar_tablero()

    def preparar_ronda(self):
        self.jugadores_eligieron = set()
        for jugador in self.juego.jugadores:
            jugador.recuperar_mana()
            jugador.robar_aleatoria()
        self.ronda_preparada = True
        self.log_combate.append(f"RONDA {len(self.log_combate) + 1}: ambos jugadores preparan sus cartas.")

    def panel_jugador(self, padre, jugador, es_actual):
        marco = tk.Frame(padre, bg=PANEL, padx=10, pady=8)
        marco.pack(side="left", fill="both", expand=True, padx=7)
        color = ACENTO if es_actual else TEXTO
        tk.Label(marco, text=jugador.nombre, bg=PANEL, fg=color,
                 font=("Arial", 15, "bold")).pack()
        tk.Label(marco, text=f"♥ Vida: {jugador.vida}     ✦ Maná: {jugador.mana}/10",
                 bg=PANEL, fg=TEXTO, font=("Arial", 11)).pack(pady=4)
        tk.Label(marco, text=f"Campo: {len(jugador.linea)} carta(s)",
                 bg=PANEL, fg=SUAVE, font=("Arial", 10)).pack(pady=(2, 4))
        fila = tk.Frame(marco, bg=PANEL)
        fila.pack()
        if not jugador.linea:
            tk.Label(fila, text="Vacío", bg=PANEL, fg="#d18b76",
                     font=("Arial", 9, "italic")).pack()
        for carta in jugador.linea:
            mini = tk.Frame(fila, bg=CARTA, padx=3, pady=3)
            mini.pack(side="left", padx=2)
            spr = tk.Canvas(mini, width=30, height=38, bg="#172337", highlightthickness=0)
            spr.pack()
            dibujar_sprite(spr, clave_carta(carta))
            tk.Label(mini, text=f"{carta.nombre}\\n{carta.vida}/{carta.vida_maxima}♥",
                     bg=CARTA, fg=TEXTO, font=("Arial", 7)).pack()

    def seleccionar_carta_turno(self, indice):
        jugador = self.juego.jugadores[self.juego.turno]
        if jugador.nombre in self.jugadores_eligieron:
            return
        salida = StringIO()
        with redirect_stdout(salida):
            correcto = self.juego.jugar_carta(jugador, indice)
        if not correcto:
            messagebox.showwarning("Maná insuficiente", "No tienes suficiente maná para esa carta.")
            return
        self.log_combate.append(f"{jugador.nombre} elige {jugador.linea[-1].nombre}.")
        self.jugadores_eligieron.add(jugador.nombre)
        self.siguiente_eleccion()

    def pasar_eleccion(self):
        jugador = self.juego.jugadores[self.juego.turno]
        if jugador.nombre in self.jugadores_eligieron:
            return
        self.log_combate.append(f"{jugador.nombre} decide no jugar carta.")
        self.jugadores_eligieron.add(jugador.nombre)
        self.siguiente_eleccion()

    def siguiente_eleccion(self):
        if len(self.jugadores_eligieron) == 2:
            self.resolver_combate()
            return
        self.juego.turno = 1 - self.juego.turno
        self.mostrar_tablero()

    def resolver_combate(self):
        self.log_combate.append("── COMIENZA EL COMBATE ──")
        salida = StringIO()
        with redirect_stdout(salida):
            self.juego.avanzar_lineas()
        texto = salida.getvalue().strip()
        self.log_combate.extend(texto.splitlines() if texto else ["No se produjo ningún enfrentamiento."])
        if any(j.vida <= 0 for j in self.juego.jugadores):
            ganador = next((j.nombre for j in self.juego.jugadores if j.vida > 0), "Empate")
            self.mostrar_tablero(fin=ganador)
            return
        self.juego.turno = 0
        self.preparar_ronda()
        self.mostrar_tablero(combate_resuelto=True)

    def mostrar_tablero(self, fin=None, combate_resuelto=False):
        self.limpiar()
        actual = self.juego.jugadores[self.juego.turno]
        self.titulo(self.root, "CAMPO DE BATALLA", 21)

        estado = tk.Frame(self.root, bg=FONDO)
        estado.pack(fill="x", padx=15, pady=4)
        for jugador in self.juego.jugadores:
            self.panel_jugador(estado, jugador, jugador is actual and fin is None)

        # Menú superior: elección de carta de esta ronda.
        menu = tk.Frame(self.root, bg=PANEL, padx=12, pady=9)
        menu.pack(fill="x", padx=15, pady=8)
        if fin:
            tk.Label(menu, text=f"¡{fin} gana la partida!", bg=PANEL, fg=ACENTO,
                     font=("Arial", 18, "bold")).pack(pady=8)
            tk.Button(menu, text="VOLVER AL INICIO", command=self.reiniciar,
                      bg=ACENTO, fg="#172033", font=("Arial", 11, "bold"),
                      padx=15, pady=8, relief="flat").pack()
        elif len(self.jugadores_eligieron) == 2:
            tk.Label(menu, text="Ambos jugadores han elegido. Combate resuelto.",
                     bg=PANEL, fg=ACENTO, font=("Arial", 13, "bold")).pack()
            tk.Button(menu, text="SIGUIENTE RONDA", command=self.nueva_ronda,
                      bg=ACENTO, fg="#172033", font=("Arial", 11, "bold"),
                      padx=15, pady=8, relief="flat").pack(pady=5)
        else:
            tk.Label(menu, text=f"RONDA · {actual.nombre.upper()} — escoge una carta",
                     bg=PANEL, fg=ACENTO, font=("Arial", 13, "bold")).pack(pady=(0, 6))
            tk.Label(menu, text=f"Maná disponible: {actual.mana}  |  Cartas en mano: {len(actual.mano)}",
                     bg=PANEL, fg=TEXTO, font=("Arial", 10)).pack()
            mano = tk.Frame(menu, bg=PANEL)
            mano.pack(fill="x", pady=5)
            if not actual.mano:
                tk.Label(mano, text="No tienes cartas disponibles. Puedes pasar.",
                         bg=PANEL, fg=SUAVE).pack()
            for i, carta in enumerate(actual.mano):
                celda = tk.Frame(mano, bg=CARTA, padx=4, pady=4)
                celda.pack(side="left", padx=4, expand=True, fill="x")
                clave = clave_carta(carta)
                spr = tk.Canvas(celda, width=40, height=48, bg="#172337", highlightthickness=0)
                spr.pack(side="left", padx=3)
                dibujar_sprite(spr, clave)
                habilitada = carta.coste <= actual.mana
                btn = tk.Button(celda,
                    text=f"{carta.nombre}\nCoste {carta.coste} · ATQ {carta.ataque} · VIDA {carta.vida}",
                    command=lambda n=i: self.seleccionar_carta_turno(n),
                    state="normal" if habilitada else "disabled",
                    wraplength=145, bg=CARTA, fg=TEXTO, disabledforeground="#7c8794",
                    activebackground=ACENTO, font=("Arial", 9), relief="flat")
                btn.pack(side="left", fill="both", expand=True)
            tk.Button(menu, text="PASAR", command=self.pasar_eleccion,
                      bg="#53647a", fg="white", font=("Arial", 10, "bold"),
                      padx=16, pady=6, relief="flat").pack(pady=4)

        # Zona de combate fija debajo del menú de elección.
        combate = tk.Frame(self.root, bg="#0b1220", padx=12, pady=8)
        combate.pack(fill="both", expand=True, padx=15, pady=(0, 12))
        tk.Label(combate, text="COMBATE · ENFRENTAMIENTOS Y ATAQUES DIRECTOS", bg="#0b1220", fg=ACENTO,
                 font=("Arial", 13, "bold")).pack(anchor="w", pady=(0, 5))
        self.log_widget = tk.Text(combate, height=13, bg="#111c2d", fg=TEXTO,
                                  insertbackground=TEXTO, relief="flat",
                                  font=("Consolas", 10), wrap="word")
        self.log_widget.pack(fill="both", expand=True)
        for linea in self.log_combate[-80:]:
            self.log_widget.insert("end", linea + "\n")
        self.log_widget.config(state="disabled")
        if fin:
            messagebox.showinfo("Fin de la partida", f"¡{fin} gana!")

    def nueva_ronda(self):
        self.juego.turno = 0
        self.preparar_ronda()
        self.mostrar_tablero()

    def reiniciar(self):
        self.juego = Juego()
        self.log_combate = []
        self._construir_inicio()


def main():
    root = tk.Tk()
    InterfazJuego(root)
    root.mainloop()


if __name__ == "__main__":
    main()
