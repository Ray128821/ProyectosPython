# Juego de cartas (prototipo de consola)

## Requisitos
- Python 3.10 o superior (no necesita instalar librerías externas).

## Ejecutar
Abre una terminal dentro de la carpeta del proyecto y ejecuta:

```bash
python main.py
```

En algunos equipos puede ser:

```bash
python3 main.py
```

## Cómo se juega
- Es un prototipo para dos jugadores en la misma consola.
- Cada jugador empieza con 20 puntos de vida.
- Antes de la partida, ambos jugadores ven las mismas 10 cartas disponibles y eligen 5 distintas.
- Al empezar cada turno recupera 4 de maná (máximo 10) y recibe una copia aleatoria de una de sus 5 cartas elegidas.
- Las 5 cartas elegidas forman un conjunto infinito: pueden volver a salir en cualquier turno y nunca se agotan.
- Puede jugar todas las cartas que pueda pagar y después escribir `r`.
- Las cartas jugadas se colocan al final de la línea propia; no empujan ni atacan al entrar.
- Al terminar cada turno, si ambos jugadores tienen cartas, sus cartas delanteras se enfrentan.
- Las cartas solo tienen ATQ y VIDA; ya no existe la defensa.
- En cada ronda de combate ambas cartas se atacan simultáneamente y cada ataque causa daño igual a su ATQ.
- El combate continúa automáticamente, sin esperar a otro turno, hasta que una o ambas cartas mueran.
- Las cartas derrotadas se retiran de la línea y se activan sus efectos de muerte.
- Las siguientes cartas pasan a ser las delanteras y se enfrentarán en el siguiente avance.
- Si un jugador no tiene cartas en su línea, la carta delantera rival puede atacar directamente y causa 1 de daño al jugador; después sale de la línea.
- Gana quien reduce la vida del rival a 0.

## Cartas incluidas
- Soldado: coste 1, ATQ 1, VIDA 4.
- Guerrero: coste 3, ATQ 3, VIDA 4. Al morir, tu siguiente carta gana +3 ATQ.
- Berserker: coste 5, ATQ 1, VIDA 6. Cuando recibe daño gana +1 ATQ.
- Gigante: coste 7, ATQ 5, VIDA 10.

## Dónde modificar
- `cartas/catalogo.py`: catálogo de cartas.
- `efectos/efectos.py`: efectos especiales.
- `jugadores/jugador.py`: vida, maná, mano y mazo.
- `combate/motor.py`: reglas y flujo del combate.


## Interfaz gráfica
Ahora puedes jugar con una ventana gráfica (Tkinter, incluido normalmente con Python):

```bash
python main.py
```

Se abrirá la interfaz de escritorio. Dos jugadores pueden compartir el mismo dispositivo para elegir sus mazos y jugar por turnos.


## Interfaz gráfica actualizada
Ejecuta `python main.py`. Cada jugador elige una carta por ronda; al confirmar ambos, el motor resuelve el combate y muestra el registro debajo del menú. Los sprites son dibujos vectoriales sencillos integrados en Tkinter.
\n\n## Regla de combate y daño directo\nEl combate continúa enfrentando las cartas delanteras mientras ambos jugadores tengan cartas en el campo. Cuando una línea queda vacía, cada carta restante de la otra línea ataca directamente al jugador rival y le resta vida según su valor de ATQ.\n