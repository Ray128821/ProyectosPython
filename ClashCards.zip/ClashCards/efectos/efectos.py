def efecto_guerrero(carta, evento):
    """Al morir, prepara +3 ATQ para la siguiente carta de su dueño."""
    if evento == "morir":
        carta.bono_siguiente_carta = 3


def efecto_berserker(carta, evento):
    """Cada vez que recibe daño efectivo, gana +1 ATQ."""
    if evento == "recibir_danio":
        carta.ataque += 1
        print(f"  ¡{carta.nombre} se enfurece y gana +1 ATQ!")
