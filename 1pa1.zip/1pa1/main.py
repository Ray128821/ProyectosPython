from interfaz_tk import main

if __name__ == "__main__":
    main()
