import time

from config import ACCIONES_POR_TURNO, ROJO, VERDE, AMARILLO, MAGENTA, GRIS, BLANCO, RESET
from acciones import Accion, TipoAccion
from utilidades import limpiar, barra_vida

ANCHO = 76

def linea():
    return "═" * ANCHO

def imprimir(texto=""):
    texto = str(texto)[:ANCHO - 2]
    print("║" + texto.center(ANCHO - 2) + "║")

def dibujar_interfaz(j1, j2, acciones1=None, acciones2=None, accion_actual=-1, mensaje=""):
    limpiar()
    print("╔" + linea() + "╗")
    imprimir("⚔ SIMULADOR DE COMBATE ⚔")
    print("╠" + linea() + "╣")
    imprimir(f"{j1.nombre[:25]:<25} VS {j2.nombre[:25]:>25}")
    imprimir(f"HP {j1.vida:>2}/20 {barra_vida(j1.vida)} VS {barra_vida(j2.vida)} HP {j2.vida:>2}/20")
    print("╠" + linea() + "╣")
    imprimir(f"{MAGENTA}🌀 FINTA{RESET}       {AMARILLO}➜ VENCE A ➜{RESET}       {AZUL}🛡 DEFENSA{RESET}")
    imprimir(f"{ROJO}⚔ ATAQUE{RESET}     {AMARILLO}➜ VENCE A ➜{RESET}       {MAGENTA}🌀 FINTA{RESET}")
    imprimir(f"{AZUL}🛡 DEFENSA{RESET}    {AMARILLO}➜ VENCE A ➜{RESET}       {ROJO}⚔ ATAQUE{RESET}")
    if acciones1 is not None and acciones2 is not None and accion_actual >= 0:
        print("╠" + linea() + "╣")
        imprimir("ACCIONES YA RESUELTAS")
        for i, (a1, a2) in enumerate(zip(acciones1, acciones2)):
            if i > accion_actual:
                break
            imprimir(f"{AMARILLO}ACCIÓN {i+1}{RESET}")
            imprimir(f"{VERDE}{j1.nombre[:18]}{RESET}: {MAGENTA if a1.tipo.name == 'FINTA' else ROJO if a1.tipo.name == 'ATAQUE' else AZUL}{a1.texto()}{RESET}")
            imprimir(f"{MAGENTA}{j2.nombre[:18]}{RESET}: {MAGENTA if a2.tipo.name == 'FINTA' else ROJO if a2.tipo.name == 'ATAQUE' else AZUL}{a2.texto()}{RESET}")
            imprimir("             ⬇  COMPARACIÓN  ⬇")
    print("╠" + linea() + "╣")
    imprimir("RESULTADO")
    for texto in (mensaje or "Esperando acciones...").split("\n"):
        imprimir(texto)
    print("╚" + linea() + "╝")

def elegir_accion(jugador, rival, numero):
    opciones = {"1": TipoAccion.FINTA, "2": TipoAccion.ATAQUE, "3": TipoAccion.DEFENSA}
    while True:
        limpiar()
        print("╔" + linea() + "╗")
        imprimir("⚔ SIMULADOR DE COMBATE ⚔")
        print("╠" + linea() + "╣")
        imprimir(f"{jugador.nombre} · HP {jugador.vida}/20")
        imprimir(f"ACCIÓN {numero}/{ACCIONES_POR_TURNO}")
        imprimir("1. FINTA")
        imprimir("2. ATAQUE")
        imprimir("3. DEFENSA")
        imprimir("Finta > Defensa · Ataque > Finta · Defensa > Ataque")
        print("╚" + linea() + "╝")
        opcion = input("\nElige una opción > ").strip()
        if opcion in opciones:
            return Accion(opciones[opcion])
        print(f"{ROJO}Opción incorrecta.{RESET}")
        time.sleep(1)

def mostrar_plan(j1, acciones1, j2, acciones2):
    # Confirmación sin revelar las elecciones antes de resolverlas.
    dibujar_interfaz(j1, j2, mensaje="Planes completados. Las elecciones siguen secretas.")
