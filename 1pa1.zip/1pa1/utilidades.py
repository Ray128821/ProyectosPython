import os

from config import LONGITUD_INTERFAZ


def limpiar():
    os.system("cls" if os.name == "nt" else "clear")


def linea():
    return "═" * LONGITUD_INTERFAZ


def barra_vida(vida, maximo=20, ancho=20):
    vida = max(0, min(vida, maximo))

    llenos = round((vida / maximo) * ancho)
    vacios = ancho - llenos

    barra = "[" + "█" * llenos + "░" * vacios + "]"

    return barra