from config import VIDA_INICIAL


class Jugador:

    def __init__(self, nombre):
        self.nombre = nombre
        self.vida = VIDA_INICIAL

        # 0 = sin contraataque
        # 2 = contraataque normal
        # 6 = contraataque fuerte
        self.contraataque = 0

        # El siguiente ataque queda anulado.
        self.ataque_anulado = False

    def recibir_danio(self, cantidad):
        self.vida -= cantidad

        if self.vida < 0:
            self.vida = 0

    def vivo(self):
        return self.vida > 0