from enum import Enum


class TipoAccion(Enum):
    FINTA = "FINTA"
    ATAQUE = "ATAQUE"
    DEFENSA = "DEFENSA"


class Accion:
    def __init__(self, tipo, altura=None):
        self.tipo = tipo

    def texto(self):
        iconos = {
            TipoAccion.FINTA: "🌀",
            TipoAccion.ATAQUE: "⚔",
            TipoAccion.DEFENSA: "🛡",
        }
        return f"{iconos[self.tipo]} {self.tipo.value}"
