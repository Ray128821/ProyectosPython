SIMULADOR DE COMBATE - INTERFAZ TKINTER

Requisitos:
- Python 3.9 o superior.
- Tkinter (normalmente viene incluido con Python).

Cómo ejecutar:
1. Descomprime esta carpeta.
2. Abre una terminal dentro de la carpeta.
3. Ejecuta: python main.py

En algunos sistemas el comando puede ser: python3 main.py

Cada jugador planifica cinco acciones por turno. Los movimientos son:
- Finta vence a Defensa.
- Ataque vence a Finta.
- Defensa vence a Ataque.
- Si ambos eligen el mismo movimiento, hay empate.
Cada intercambio ganado inflige 1 punto de daño.
