from acciones import TipoAccion


# La clave es el movimiento ganador y el valor es el movimiento al que vence.
VENTAJAS = {
    TipoAccion.FINTA: TipoAccion.DEFENSA,
    TipoAccion.ATAQUE: TipoAccion.FINTA,
    TipoAccion.DEFENSA: TipoAccion.ATAQUE,
}


def resolver_accion(j1, accion1, j2, accion2):
    tipo1 = accion1.tipo
    tipo2 = accion2.tipo

    if tipo1 == tipo2:
        return f"🤝 EMPATE: ambos eligieron {tipo1.value}. Nadie recibe daño."

    if VENTAJAS[tipo1] == tipo2:
        j2.recibir_danio(1)
        return (
            f"✅ {tipo1.value} vence a {tipo2.value}. "
            f"{j1.nombre} gana el intercambio e inflige 1 de daño a {j2.nombre}."
        )

    j1.recibir_danio(1)
    return (
        f"✅ {tipo2.value} vence a {tipo1.value}. "
        f"{j2.nombre} gana el intercambio e inflige 1 de daño a {j1.nombre}."
    )
