from config import ACCIONES_POR_TURNO
from jugador import Jugador
from utilidades import limpiar, linea
from interfaz import (
    elegir_accion,
    mostrar_plan,
    dibujar_interfaz,
)
from combate import resolver_accion


def recoger_acciones(jugador, rival):
    acciones = []

    for i in range(1, ACCIONES_POR_TURNO + 1):
        accion = elegir_accion(
            jugador,
            rival,
            i
        )

        acciones.append(accion)

    return acciones


def ejecutar_turno(j1, j2):
    # Fase de planificación.
    acciones1 = recoger_acciones(j1, j2)
    acciones2 = recoger_acciones(j2, j1)

    # Confirmar que ambos planes están completos sin revelar las elecciones.
    mostrar_plan(
        j1,
        acciones1,
        j2,
        acciones2
    )

    # Resolver las acciones en orden.
    for i in range(ACCIONES_POR_TURNO):
        if not j1.vivo() or not j2.vivo():
            break

        mensaje = resolver_accion(
            j1,
            acciones1[i],
            j2,
            acciones2[i]
        )

        dibujar_interfaz(
            j1,
            j2,
            acciones1,
            acciones2,
            i,
            mensaje
        )

        import time
        time.sleep(2)


def jugar():
    limpiar()

    print("╔" + linea() + "╗")
    print("║" + "⚔  SIMULADOR DE COMBATE  ⚔".center(74) + "║")
    print("╚" + linea() + "╝")
    print()

    nombre1 = input("Nombre del jugador 1: ").strip()
    nombre2 = input("Nombre del jugador 2: ").strip()

    if not nombre1:
        nombre1 = "Jugador 1"

    if not nombre2:
        nombre2 = "Jugador 2"

    j1 = Jugador(nombre1)
    j2 = Jugador(nombre2)

    turno = 1

    # Bucle principal del combate.
    while j1.vivo() and j2.vivo():
        ejecutar_turno(j1, j2)

        if j1.vivo() and j2.vivo():
            limpiar()

            dibujar_interfaz(
                j1,
                j2,
                mensaje=(
                    f"FIN DEL TURNO {turno}\n"
                    "Ambos combatientes siguen en pie."
                )
            )

            input(
                "\nPulsa ENTER para comenzar "
                "el siguiente turno..."
            )

        turno += 1

    # Determinar el ganador.
    limpiar()

    if j1.vivo() and not j2.vivo():
        ganador = j1.nombre
    elif j2.vivo() and not j1.vivo():
        ganador = j2.nombre
    else:
        ganador = "EMPATE"

    dibujar_interfaz(
        j1,
        j2,
        mensaje=(
            "🏆 FIN DEL COMBATE\n"
            f"GANADOR: {ganador}"
        )
    )

    print()