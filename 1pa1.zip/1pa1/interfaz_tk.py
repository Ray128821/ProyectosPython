import tkinter as tk
from config import VIDA_INICIAL, ACCIONES_POR_TURNO
from jugador import Jugador
from acciones import Accion, TipoAccion
from combate import resolver_accion


# Paleta visual
BG = "#111827"
PANEL = "#1f2937"
PANEL2 = "#273449"
TEXT = "#f3f4f6"
MUTED = "#9ca3af"
GREEN = "#22c55e"
PINK = "#e879f9"
RED = "#ef4444"
GOLD = "#fbbf24"
BLUE = "#60a5fa"


class JuegoTkinter:
    def __init__(self, root):
        self.root = root
        self.root.title("Simulador de combate")

        # Ventana normal, no maximizada ni a pantalla completa
        self.root.geometry("960x740")
        self.root.minsize(860, 680)
        self.root.configure(bg=BG)

        self.j1 = None
        self.j2 = None
        self.turno = 1
        self.jugador_actual = 0
        self.indice_accion = 0
        self.resolucion_activa = False
        self.esperando_siguiente_turno = False
        self.acciones1 = []
        self.acciones2 = []
        self.registro_turnos = {}
        self.turno_vista = 1

        self._crear_inicio()

    def _label(self, parent, text, size=12, color=TEXT, bold=False, **kwargs):
        bg = kwargs.pop("bg", parent.cget("bg"))
        return tk.Label(
            parent,
            text=text,
            bg=bg,
            fg=color,
            font=("Segoe UI", size, "bold" if bold else "normal"),
            **kwargs
        )

    def _limpiar(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def _crear_inicio(self):
        self._limpiar()

        outer = tk.Frame(self.root, bg=BG, padx=30, pady=25)
        outer.pack(fill="both", expand=True)

        self._label(
            outer, "⚔  SIMULADOR DE COMBATE  ⚔",
            24, GOLD, True
        ).pack(pady=(35, 8))

        self._label(
            outer,
            "Combate por turnos · Finta, Ataque y Defensa",
            12, MUTED
        ).pack(pady=(0, 28))

        form = tk.Frame(outer, bg=PANEL, padx=26, pady=26)
        form.pack()

        self._label(
            form, "NOMBRES DE LOS COMBATIENTES",
            12, TEXT, True, bg=PANEL
        ).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 16))

        self._label(
            form, "Jugador 1", 11, GREEN, True, bg=PANEL
        ).grid(row=1, column=0, sticky="w", padx=(0, 16), pady=8)

        self.nombre1 = tk.Entry(form, font=("Segoe UI", 12), width=24, relief="flat")
        self.nombre1.insert(0, "Jugador 1")
        self.nombre1.grid(row=1, column=1, ipady=7, pady=8)

        self._label(
            form, "Jugador 2", 11, PINK, True, bg=PANEL
        ).grid(row=2, column=0, sticky="w", padx=(0, 16), pady=8)

        self.nombre2 = tk.Entry(form, font=("Segoe UI", 12), width=24, relief="flat")
        self.nombre2.insert(0, "Jugador 2")
        self.nombre2.grid(row=2, column=1, ipady=7, pady=8)

        tk.Button(
            outer,
            text="COMENZAR COMBATE",
            command=self._comenzar,
            bg=GREEN,
            fg="#052e16",
            activebackground="#16a34a",
            activeforeground="white",
            font=("Segoe UI", 12, "bold"),
            relief="flat",
            padx=26,
            pady=12,
            cursor="hand2"
        ).pack(pady=(24, 8))

        self._label(outer, "O PULSA ESPACIO PARA COMENZAR", 9, MUTED, True).pack()
        self.root.bind("<space>", self._espacio_inicio)

    def _espacio_inicio(self, event=None):
        self._comenzar()
        return "break"

    def _comenzar(self):
        nombre1 = self.nombre1.get().strip() or "Jugador 1"
        nombre2 = self.nombre2.get().strip() or "Jugador 2"

        self.j1 = Jugador(nombre1)
        self.j2 = Jugador(nombre2)
        self.turno = 1
        self.registro_turnos = {}
        self.turno_vista = 1
        self._crear_juego()
        self._nuevo_turno()

    def _crear_juego(self):
        self._limpiar()

        header = tk.Frame(self.root, bg=BG, padx=20, pady=14)
        header.pack(fill="x")

        self._label(
            header, "⚔  SIMULADOR DE COMBATE",
            18, GOLD, True, bg=BG
        ).pack(side="left")

        self.turno_label = self._label(
            header, "TURNO 1", 11, MUTED, True, bg=BG
        )
        self.turno_label.pack(side="right")

        # Dos columnas idénticas para que las tarjetas sean simétricas
        fighters = tk.Frame(self.root, bg=BG, padx=20)
        fighters.pack(fill="x")
        fighters.columnconfigure(0, weight=1, uniform="jugadores")
        fighters.columnconfigure(1, weight=1, uniform="jugadores")

        self.card1 = self._crear_tarjeta(fighters, self.j1, GREEN)
        self.card1.grid(row=0, column=0, sticky="nsew", padx=(0, 8))

        self.card2 = self._crear_tarjeta(fighters, self.j2, PINK)
        self.card2.grid(row=0, column=1, sticky="nsew", padx=(8, 0))

        self.status_label = self._label(
            self.root, "Prepara tus acciones", 13, TEXT, True, bg=BG
        )
        self.status_label.pack(pady=(12, 8))

        self.action_panel = tk.Frame(
            self.root, bg=PANEL, padx=16, pady=13
        )
        self.action_panel.pack(fill="x", padx=20, pady=4)

        self.log_frame = tk.Frame(self.root, bg=BG, padx=20, pady=8)
        self.log_frame.pack(fill="x", expand=False)

        log_header = tk.Frame(self.log_frame, bg=BG)
        log_header.pack(fill="x")
        self._label(
            log_header, "REGISTRO DEL COMBATE",
            10, MUTED, True, bg=BG
        ).pack(side="left")

        self.log_turn_label = self._label(
            log_header, "TURNO 1", 9, GOLD, True, bg=BG
        )
        self.log_turn_label.pack(side="left", padx=(12, 0))

        nav = tk.Frame(log_header, bg=BG)
        nav.pack(side="right")
        self.log_prev_button = tk.Button(
            nav, text="◀", command=lambda: self._navegar_registro(-1),
            bg=PANEL2, fg=TEXT, activebackground=GOLD,
            relief="flat", font=("Segoe UI", 9, "bold"),
            padx=9, pady=2, cursor="hand2"
        )
        self.log_prev_button.pack(side="left", padx=(0, 5))
        self.log_next_button = tk.Button(
            nav, text="▶", command=lambda: self._navegar_registro(1),
            bg=PANEL2, fg=TEXT, activebackground=GOLD,
            relief="flat", font=("Segoe UI", 9, "bold"),
            padx=9, pady=2, cursor="hand2"
        )
        self.log_next_button.pack(side="left")

        self.log = tk.Text(
            self.log_frame,
            height=2,
            bg="#0b1220",
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
            wrap="word",
            font=("Consolas", 13, "bold"),
            padx=10,
            pady=8,
            state="disabled"
        )
        self.log.pack(fill="x", expand=False, pady=(6, 0))
        self.root.bind("<Left>", lambda event: self._navegar_registro(-1))
        self.root.bind("<Right>", lambda event: self._navegar_registro(1))

        self.footer = tk.Frame(self.root, bg=BG, padx=20, pady=10)
        self.footer.pack(fill="x")

        self.root.bind("<KeyPress-1>", lambda event: self._seleccionar_tecla(TipoAccion.FINTA))
        self.root.bind("<KeyPress-2>", lambda event: self._seleccionar_tecla(TipoAccion.ATAQUE))
        self.root.bind("<KeyPress-3>", lambda event: self._seleccionar_tecla(TipoAccion.DEFENSA))
        self.root.bind("<space>", self._espacio_continuar)
        self.root.after(100, self._actualizar_tarjetas)

    def _crear_tarjeta(self, parent, jugador, color):
        card = tk.Frame(parent, bg=PANEL, padx=14, pady=12)

        self._label(
            card, jugador.nombre, 14, color, True, bg=PANEL
        ).pack(anchor="w")

        row = tk.Frame(card, bg=PANEL)
        row.pack(fill="x", pady=(9, 5))

        hp_label = self._label(
            row, f"{jugador.vida}/{VIDA_INICIAL} HP",
            10, TEXT, True, bg=PANEL
        )
        hp_label.pack(side="left")

        bar = tk.Canvas(
            card,
            height=14,
            bg=PANEL2,
            highlightthickness=0,
            bd=0
        )
        bar.pack(fill="x", pady=(0, 7))

        state_label = self._label(
            card, "Listo", 9, MUTED, bg=PANEL, anchor="w"
        )
        state_label.pack(anchor="w")

        card.hp_label = hp_label
        card.bar = bar
        card.state_label = state_label
        card.player = jugador
        card.color = color

        # Repintar cuando Tkinter cambie el tamaño de la barra
        bar.bind(
            "<Configure>",
            lambda event: self.root.after_idle(self._actualizar_tarjetas)
        )
        return card

    def _actualizar_tarjetas(self):
        if not self.j1 or not self.j2:
            return

        for card in (self.card1, self.card2):
            jugador = card.player
            vida_maxima = VIDA_INICIAL
            vida_actual = max(0, min(vida_maxima, jugador.vida))

            card.hp_label.config(
                text=f"{vida_actual}/{vida_maxima} HP"
            )

            card.bar.delete("all")
            ancho = card.bar.winfo_width()
            alto = card.bar.winfo_height()

            if ancho <= 1 or alto <= 1:
                continue

            # Fondo completo y porción proporcional a la vida restante
            card.bar.create_rectangle(
                0, 0, ancho, alto,
                fill=PANEL2, outline=""
            )

            proporcion = vida_actual / vida_maxima if vida_maxima else 0
            ancho_vida = ancho * proporcion

            if ancho_vida > 0:
                card.bar.create_rectangle(
                    0, 0, ancho_vida, alto,
                    fill=card.color, outline=""
                )

            estados = []
            if getattr(jugador, "contraataque", 0) > 0:
                estados.append(f"Contraataque ×{jugador.contraataque}")
            if getattr(jugador, "ataque_anulado", False):
                estados.append("Próximo ataque anulado")

            card.state_label.config(
                text=" · ".join(estados) if estados else "Listo"
            )

    def _log(self, texto):
        # Cada turno conserva su propio registro para poder consultarlo después.
        lineas = [linea for linea in texto.splitlines() if linea.strip()]
        if not lineas and texto.strip():
            lineas = [texto.strip()]
        registro = self.registro_turnos.setdefault(self.turno, [])
        registro.extend(lineas)
        # Si se está jugando el turno actual, seguir mostrando ese turno.
        self.turno_vista = self.turno
        self._mostrar_registro_turno()

    def _mostrar_registro_turno(self):
        if not hasattr(self, "log") or not self.log.winfo_exists():
            return
        lineas = self.registro_turnos.get(self.turno_vista, [])
        contenido = "\n".join(lineas) if lineas else "Todavía no hay registros para este turno."
        # El cuadro se ajusta al número de líneas del turno, sin ocupar espacio sobrante.
        alto = max(2, len(contenido.splitlines()))
        self.log.config(state="normal", height=alto)
        self.log.delete("1.0", "end")
        self.log.insert("1.0", contenido)
        self.log.config(state="disabled")
        self.log_turn_label.config(text=f"TURNO {self.turno_vista}")
        turnos = sorted(self.registro_turnos)
        self.log_prev_button.config(state="normal" if turnos and self.turno_vista > turnos[0] else "disabled")
        self.log_next_button.config(state="normal" if turnos and self.turno_vista < turnos[-1] else "disabled")

    def _navegar_registro(self, direccion):
        if not hasattr(self, "log") or not self.log.winfo_exists():
            return "break"
        turnos = sorted(self.registro_turnos)
        if not turnos:
            return "break"
        objetivo = self.turno_vista + direccion
        if objetivo in self.registro_turnos:
            self.turno_vista = objetivo
            self._mostrar_registro_turno()
        return "break"

    def _limpiar_panel(self):
        for widget in self.action_panel.winfo_children():
            widget.destroy()
        for widget in self.footer.winfo_children():
            widget.destroy()

    def _nuevo_turno(self):
        if not self.j1.vivo() or not self.j2.vivo():
            self._fin()
            return

        self.turno_label.config(text=f"TURNO {self.turno}")
        self.acciones1 = []
        self.acciones2 = []
        self.jugador_actual = 0
        self.indice_accion = 0
        self.resolucion_activa = False
        self.esperando_siguiente_turno = False

        self.registro_turnos.setdefault(self.turno, [])
        self._log(f"— TURNO {self.turno} —")
        self._actualizar_tarjetas()
        self._pedir_accion()
        self._mostrar_modal_turno()

    def _pedir_accion(self):
        self._limpiar_panel()

        jugador = self.j1 if self.jugador_actual == 0 else self.j2
        acciones = self.acciones1 if self.jugador_actual == 0 else self.acciones2
        color = GREEN if self.jugador_actual == 0 else PINK

        self.status_label.config(
            text=f"{jugador.nombre}: elige la acción {len(acciones) + 1} de {ACCIONES_POR_TURNO}"
        )

        self._label(
            self.action_panel, f"PLANIFICACIÓN · {jugador.nombre}",
            11, color, True, bg=PANEL, anchor="center"
        ).pack(fill="x", pady=(0, 5))
        self._label(
            self.action_panel,
            "Elige tu siguiente movimiento",
            10, MUTED, bg=PANEL, anchor="center"
        ).pack(fill="x", pady=(0, 8))

        self._label(
            self.action_panel,
            "PULSA 1, 2 o 3 PARA ELEGIR",
            9, GOLD, True, bg=PANEL, anchor="center"
        ).pack(fill="x", pady=(0, 5))

        grid = tk.Frame(self.action_panel, bg=PANEL)
        grid.pack(fill="x")

        opciones = [
            ("1  ·  🌀 FINTA", TipoAccion.FINTA, PINK),
            ("2  ·  ⚔ ATAQUE", TipoAccion.ATAQUE, RED),
            ("3  ·  🛡 DEFENSA", TipoAccion.DEFENSA, BLUE),
        ]

        for indice, (texto, tipo, color_boton) in enumerate(opciones):
            boton = tk.Button(
                grid,
                text=texto,
                command=lambda t=tipo: self._seleccionar(t),
                bg=PANEL2,
                fg=TEXT,
                activebackground=color_boton,
                activeforeground="white",
                font=("Segoe UI", 10, "bold"),
                relief="flat",
                padx=8,
                pady=12,
                cursor="hand2"
            )
            boton.grid(
                row=0,
                column=indice,
                sticky="ew",
                padx=4,
                pady=4
            )

        for columna in range(3):
            grid.columnconfigure(columna, weight=1, uniform="acciones")

        # Reglas más grandes y visuales, con una tarjeta por enfrentamiento.
        reglas = tk.Frame(self.action_panel, bg=PANEL)
        reglas.pack(fill="x", pady=(12, 2))
        enfrentamientos = [
            ("🌀 FINTA", "vence a", "🛡 DEFENSA", PINK, BLUE),
            ("⚔ ATAQUE", "vence a", "🌀 FINTA", RED, PINK),
            ("🛡 DEFENSA", "vence a", "⚔ ATAQUE", BLUE, RED),
        ]
        for columna, (ganador, verbo, perdedor, color_gana, color_pierde) in enumerate(enfrentamientos):
            tarjeta = tk.Frame(reglas, bg=PANEL2, padx=8, pady=9)
            tarjeta.grid(row=0, column=columna, sticky="nsew", padx=4)
            self._label(tarjeta, ganador, 11, color_gana, True, bg=PANEL2, anchor="center").pack(fill="x")
            self._label(tarjeta, verbo.upper(), 8, GOLD, True, bg=PANEL2, anchor="center").pack(fill="x", pady=2)
            self._label(tarjeta, perdedor, 11, color_pierde, True, bg=PANEL2, anchor="center").pack(fill="x")
            reglas.columnconfigure(columna, weight=1, uniform="reglas")

        self._label(
            self.action_panel,
            f"Acciones seleccionadas: {len(acciones)}/{ACCIONES_POR_TURNO}",
            9, MUTED, bg=PANEL
        ).pack(anchor="e", pady=(6, 0))

    def _seleccionar_tecla(self, tipo):
        # Las teclas numéricas solo seleccionan acciones durante la planificación.
        if self.jugador_actual not in (0, 1):
            return
        if len(self.acciones1 if self.jugador_actual == 0 else self.acciones2) >= ACCIONES_POR_TURNO:
            return
        self._seleccionar(tipo)

    def _seleccionar(self, tipo):
        accion = Accion(tipo)
        lista = self.acciones1 if self.jugador_actual == 0 else self.acciones2
        lista.append(accion)

        nombre = self.j1.nombre if self.jugador_actual == 0 else self.j2.nombre
        self._log(f"{nombre}: acción {len(lista)} guardada.")

        if len(lista) >= ACCIONES_POR_TURNO:
            if self.jugador_actual == 0:
                self.jugador_actual = 1
                self._pedir_accion()
                self._mostrar_modal_turno()
            else:
                self._mostrar_plan()
        else:
            self._pedir_accion()

    def _mostrar_modal_turno(self):
        """Pantalla breve que indica qué jugador debe planificar en privado."""
        if hasattr(self, "modal_turno_overlay") and self.modal_turno_overlay.winfo_exists():
            self.modal_turno_overlay.destroy()

        jugador = self.j1 if self.jugador_actual == 0 else self.j2
        color = GREEN if self.jugador_actual == 0 else PINK
        # Tramado semitransparente: oscurece sin ocultar por completo el menú.
        overlay = tk.Canvas(self.root, bg=BG, highlightthickness=0, bd=0)
        overlay.place(x=0, y=0, relwidth=1, relheight=1)
        overlay.create_rectangle(0, 0, 2000, 2000, fill="#000000", outline="", stipple="gray25")
        self.modal_turno_overlay = overlay

        dialog = tk.Frame(overlay, bg=PANEL, padx=38, pady=28,
                          highlightbackground=color, highlightthickness=2)
        ventana_dialogo = overlay.create_window(
            self.root.winfo_width() / 2, self.root.winfo_height() / 2,
            window=dialog, anchor="center", width=520
        )
        overlay.bind("<Configure>", lambda event: overlay.coords(
            ventana_dialogo, event.width / 2, event.height / 2
        ))
        self._label(dialog, f"TURNO {self.turno}", 12, GOLD, True, bg=PANEL, anchor="center").pack(fill="x", pady=(0, 8))
        self._label(dialog, "LE TOCA A", 14, MUTED, True, bg=PANEL, anchor="center").pack(fill="x")
        self._label(dialog, jugador.nombre.upper(), 24, color, True, bg=PANEL, anchor="center", wraplength=460).pack(fill="x", pady=(3, 12))
        self._label(dialog, "Pulsa ESPACIO para continuar", 9, MUTED, bg=PANEL, anchor="center").pack(fill="x", pady=(0, 6))
        tk.Button(dialog, text="CONTINUAR", command=self._cerrar_modal_turno,
                  bg=color, fg="#111827", activebackground=color,
                  font=("Segoe UI", 12, "bold"), relief="flat",
                  padx=30, pady=10, cursor="hand2").pack()
        overlay.lift()

    def _cerrar_modal_turno(self):
        if hasattr(self, "modal_turno_overlay") and self.modal_turno_overlay.winfo_exists():
            self.modal_turno_overlay.destroy()

    def _mostrar_plan(self):
        self._limpiar_panel()
        self.resolucion_activa = False
        self.status_label.config(text="Planes listos · comienza la resolución")

        self._label(
            self.action_panel, "PLANES COMPLETADOS",
            14, GOLD, True, bg=PANEL, anchor="center"
        ).pack(fill="x", pady=(12, 8))
        self._label(
            self.action_panel,
            "Las elecciones permanecen secretas hasta resolver cada acción.",
            10, MUTED, bg=PANEL, anchor="center", justify="center"
        ).pack(fill="x", pady=(0, 12))

        # No mostrar las acciones elegidas antes de resolverlas.
        # Capa oscura sobre toda la ventana y diálogo centrado encima del menú.
        self._mostrar_modal_resolver()

        self._log("Ambos jugadores han completado su plan.")

    def _mostrar_modal_resolver(self):
        # Canvas a pantalla completa: el tramado negro oscurece visualmente el menú.
        self.modal_overlay = tk.Canvas(
            self.root, bg=BG, highlightthickness=0, bd=0
        )
        self.modal_overlay.place(x=0, y=0, relwidth=1, relheight=1)
        self.modal_overlay.create_rectangle(
            0, 0, 2000, 2000, fill="#000000", outline="", stipple="gray25"
        )

        dialog = tk.Frame(self.modal_overlay, bg=PANEL, padx=34, pady=28,
                          highlightbackground=GOLD, highlightthickness=2)
        ventana_dialogo = self.modal_overlay.create_window(
            self.root.winfo_width() / 2, self.root.winfo_height() / 2,
            window=dialog, anchor="center", width=520, height=270
        )
        self.modal_overlay.bind(
            "<Configure>",
            lambda event: self.modal_overlay.coords(
                ventana_dialogo, event.width / 2, event.height / 2
            )
        )
        self._label(
            dialog, "PLANES COMPLETADOS", 13, GOLD, True, bg=PANEL,
            anchor="center"
        ).pack(fill="x", pady=(8, 12))
        self._label(
            dialog, "Ambos jugadores han elegido todas sus acciones.\n¿Listos para resolver el combate?",
            10, TEXT, bg=PANEL, justify="center", anchor="center", wraplength=460
        ).pack(fill="x", pady=(0, 14))
        self._label(
            dialog, "Pulsa ESPACIO para resolver",
            9, MUTED, bg=PANEL, anchor="center"
        ).pack(fill="x", pady=(0, 6))
        tk.Button(
            dialog, text="RESOLVER", command=self._cerrar_modal_y_resolver,
            bg=GOLD, fg="#422006", activebackground="#f59e0b",
            font=("Segoe UI", 14, "bold"), relief="flat",
            padx=46, pady=14, cursor="hand2", width=18, height=2
        ).pack()
        self.modal_overlay.lift()

    def _cerrar_modal_y_resolver(self):
        if hasattr(self, "modal_overlay") and self.modal_overlay.winfo_exists():
            self.modal_overlay.destroy()
        self.resolucion_activa = True
        self._resolver_siguiente()

    def _espacio_continuar(self, event=None):
        # Primero cierra el aviso del jugador; no avanza la acción en ese mismo toque.
        if hasattr(self, "modal_turno_overlay") and self.modal_turno_overlay.winfo_exists():
            self._cerrar_modal_turno()
        elif hasattr(self, "modal_overlay") and self.modal_overlay.winfo_exists():
            self._cerrar_modal_y_resolver()
        elif self.resolucion_activa:
            self._resolver_siguiente()
        elif self.esperando_siguiente_turno:
            self._nuevo_turno()
        return "break"

    def _resolver_siguiente(self):
        if (
            self.indice_accion >= ACCIONES_POR_TURNO
            or not self.j1.vivo()
            or not self.j2.vivo()
        ):
            self._fin_turno()
            return

        indice = self.indice_accion
        mensaje = resolver_accion(
            self.j1, self.acciones1[indice],
            self.j2, self.acciones2[indice]
        )

        self._log(
            f"Acción {indice + 1}: {mensaje.replace(chr(10), ' ')}"
        )

        self.indice_accion += 1
        self._actualizar_tarjetas()
        self._limpiar_panel()
        self.resolucion_activa = True

        self.status_label.config(
            text=f"Resolución · acción {self.indice_accion}/{ACCIONES_POR_TURNO}"
        )

        self._label(
            self.action_panel, f"ACCIÓN {indice + 1}",
            11, GOLD, True, bg=PANEL
        ).pack(anchor="w", pady=(0, 7))

        # Duelo visual: cada acción aparece en su propia tarjeta, frente a frente.
        duelo = tk.Frame(self.action_panel, bg=PANEL)
        duelo.pack(fill="x", pady=(4, 8))
        colores_accion = {
            TipoAccion.FINTA: ("🌀", "FINTA", PINK),
            TipoAccion.ATAQUE: ("⚔", "ATAQUE", RED),
            TipoAccion.DEFENSA: ("🛡", "DEFENSA", BLUE),
        }
        icono1, nombre_accion1, color1 = colores_accion[self.acciones1[indice].tipo]
        icono2, nombre_accion2, color2 = colores_accion[self.acciones2[indice].tipo]
        tarjeta1 = tk.Frame(duelo, bg=PANEL2, padx=10, pady=8, highlightbackground=color1, highlightthickness=2)
        tarjeta1.grid(row=0, column=0, sticky="nsew", padx=(0, 5))
        self._label(tarjeta1, self.j1.nombre.upper(), 9, MUTED, True, bg=PANEL2, anchor="center").pack(fill="x")
        self._label(tarjeta1, icono1, 25, color1, True, bg=PANEL2, anchor="center").pack(fill="x", pady=(3, 0))
        self._label(tarjeta1, nombre_accion1, 15, color1, True, bg=PANEL2, anchor="center").pack(fill="x")

        centro = tk.Frame(duelo, bg=PANEL)
        centro.grid(row=0, column=1, sticky="ns", padx=5)
        self._label(centro, "VS", 16, GOLD, True, bg=PANEL, anchor="center").pack(expand=True)

        tarjeta2 = tk.Frame(duelo, bg=PANEL2, padx=10, pady=8, highlightbackground=color2, highlightthickness=2)
        tarjeta2.grid(row=0, column=2, sticky="nsew", padx=(5, 0))
        self._label(tarjeta2, self.j2.nombre.upper(), 9, MUTED, True, bg=PANEL2, anchor="center").pack(fill="x")
        self._label(tarjeta2, icono2, 25, color2, True, bg=PANEL2, anchor="center").pack(fill="x", pady=(3, 0))
        self._label(tarjeta2, nombre_accion2, 15, color2, True, bg=PANEL2, anchor="center").pack(fill="x")
        duelo.columnconfigure(0, weight=1, uniform="duelo")
        duelo.columnconfigure(2, weight=1, uniform="duelo")

        self._label(
            self.action_panel, mensaje, 18, GOLD, True, bg=PANEL,
            justify="center", anchor="center", wraplength=820
        ).pack(fill="x", pady=(8, 12))

        quedan_acciones = (
            self.indice_accion < ACCIONES_POR_TURNO
            and self.j1.vivo()
            and self.j2.vivo()
        )
        texto_boton = "SIGUIENTE ACCIÓN  →" if quedan_acciones else "FINALIZAR TURNO  →"
        self._label(
            self.footer, "Pulsa ESPACIO para continuar",
            9, MUTED, bg=BG, anchor="center"
        ).pack(fill="x", pady=(0, 5))

        tk.Button(
            self.footer,
            text=texto_boton,
            command=self._resolver_siguiente,
            bg=GOLD,
            fg="#422006",
            activebackground="#f59e0b",
            font=("Segoe UI", 12, "bold"),
            relief="flat",
            width=24,
            height=2,
            cursor="hand2"
        ).pack(anchor="center")

        if not self.j1.vivo() or not self.j2.vivo():
            self.root.after(100, self._comprobar_fin)

    def _comprobar_fin(self):
        if not self.j1.vivo() or not self.j2.vivo():
            self._fin()

    def _fin_turno(self):
        self.resolucion_activa = False
        if not self.j1.vivo() or not self.j2.vivo():
            self._fin()
            return

        self.esperando_siguiente_turno = True
        self.turno += 1
        self._limpiar_panel()
        self.status_label.config(text=f"Fin del turno {self.turno - 1}")

        self._label(
            self.action_panel,
            "Ambos combatientes siguen en pie.",
            11, TEXT, bg=PANEL
        ).pack(anchor="w", pady=8)

        self._label(
            self.footer, "Pulsa ESPACIO para comenzar el siguiente turno",
            9, MUTED, bg=BG, anchor="center"
        ).pack(fill="x", pady=(0, 5))

        tk.Button(
            self.footer,
            text="COMENZAR SIGUIENTE TURNO  →",
            command=self._nuevo_turno,
            bg=GREEN,
            fg="#052e16",
            activebackground="#16a34a",
            font=("Segoe UI", 10, "bold"),
            relief="flat",
            padx=18,
            pady=9,
            cursor="hand2"
        ).pack(side="right")

    def _fin(self):
        self._limpiar_panel()

        if self.j1.vivo() and not self.j2.vivo():
            ganador = self.j1.nombre
        elif self.j2.vivo() and not self.j1.vivo():
            ganador = self.j2.nombre
        else:
            ganador = "EMPATE"

        self.status_label.config(text="🏆  FIN DEL COMBATE")

        self._label(
            self.action_panel, f"GANADOR: {ganador}",
            18, GOLD, True, bg=PANEL
        ).pack(pady=16)

        tk.Button(
            self.footer,
            text="NUEVA PARTIDA",
            command=self._crear_inicio,
            bg=GREEN,
            fg="#052e16",
            activebackground="#16a34a",
            font=("Segoe UI", 10, "bold"),
            relief="flat",
            padx=18,
            pady=9,
            cursor="hand2"
        ).pack(side="right")

        self._log(f"FIN DEL COMBATE · GANADOR: {ganador}")
        self._actualizar_tarjetas()


def main():
    root = tk.Tk()
    JuegoTkinter(root)
    root.mainloop()


if __name__ == "__main__":
    main()
